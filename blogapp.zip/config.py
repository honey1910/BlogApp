class Config:
    SECRET_KEY = 'a3c9e2d0b8d4e5f1a2b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0'
    MONGO_URI = 'mongodb+srv://mernchat:4jHqMihus0fATQDT@cluster0.ahsmrmz.mongodb.net/Blog'
